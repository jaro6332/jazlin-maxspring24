require("./lib/n4m.typescript.js");
